package com.taskmanager.enums;

public enum ActivityType {
    TASK_CREATED,
    STATUS_CHANGED,
    PRIORITY_CHANGED,
    ASSIGNEE_CHANGED,
    DUE_DATE_CHANGED,
    TITLE_CHANGED,
    DESCRIPTION_CHANGED,
    COMMENT_ADDED
}
