package com.taskmanager.dto.response;

import com.taskmanager.enums.ActivityType;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class TaskActivityResponse {

    private Long id;
    private Long taskId;
    private ActivityType activityType;
    private String oldValue;
    private String newValue;
    private UserResponse updatedBy;
    private LocalDateTime timestamp;
}
