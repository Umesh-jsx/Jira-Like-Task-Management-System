package com.taskmanager.enums;

public enum UserRole {
    ADMIN,
    MANAGER,
    DEVELOPER,
    TESTER
}
