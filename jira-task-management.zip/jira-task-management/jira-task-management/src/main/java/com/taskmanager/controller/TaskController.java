package com.taskmanager.controller;

import com.taskmanager.dto.request.AddCommentRequest;
import com.taskmanager.dto.request.CreateTaskRequest;
import com.taskmanager.dto.request.UpdateTaskRequest;
import com.taskmanager.dto.response.*;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.service.TaskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Task Management", description = "APIs for managing tasks")
public class TaskController {

    private final TaskService taskService;

    // ─── CRUD ────────────────────────────────────────────────────────────────────

    @PostMapping
    @Operation(summary = "Create a new task")
    public ResponseEntity<ApiResponse<TaskResponse>> createTask(@Valid @RequestBody CreateTaskRequest request) {
        log.info("POST /api/tasks - Creating task: {}", request.getTitle());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(taskService.createTask(request), "Task created successfully"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get task by ID")
    public ResponseEntity<ApiResponse<TaskResponse>> getTaskById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getTaskById(id)));
    }

    @GetMapping
    @Operation(summary = "Get all tasks with optional keyword search and pagination")
    public ResponseEntity<ApiResponse<Page<TaskResponse>>> getAllTasks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) TaskStatus status) {
        Sort sort = direction.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<TaskResponse> result;
        if (keyword != null && !keyword.isBlank()) {
            result = taskService.searchTasks(keyword, pageable);
        } else if (status != null) {
            result = taskService.getTasksByStatus(status, pageable);
        } else {
            result = taskService.getAllTasks(pageable);
        }
        return ResponseEntity.ok(ApiResponse.success(result));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a task (with audit tracking)")
    public ResponseEntity<ApiResponse<TaskResponse>> updateTask(
            @PathVariable Long id,
            @Valid @RequestBody UpdateTaskRequest request) {
        log.info("PUT /api/tasks/{}", id);
        return ResponseEntity.ok(ApiResponse.success(taskService.updateTask(id, request), "Task updated successfully"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a task")
    public ResponseEntity<ApiResponse<Void>> deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Task deleted successfully"));
    }

    // ─── Filter by Project ───────────────────────────────────────────────────────

    @GetMapping("/project/{projectId}")
    @Operation(summary = "Get tasks by project with optional filters")
    public ResponseEntity<ApiResponse<Page<TaskResponse>>> getTasksByProject(
            @PathVariable Long projectId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction,
            @RequestParam(required = false) TaskStatus status,
            @RequestParam(required = false) TaskPriority priority,
            @RequestParam(required = false) String keyword) {
        Sort sort = direction.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<TaskResponse> result;
        if (keyword != null && !keyword.isBlank()) {
            result = taskService.searchTasksByProject(projectId, keyword, pageable);
        } else if (status != null) {
            result = taskService.getTasksByProjectAndStatus(projectId, status, pageable);
        } else if (priority != null) {
            result = taskService.getTasksByProjectAndPriority(projectId, priority, pageable);
        } else {
            result = taskService.getTasksByProject(projectId, pageable);
        }
        return ResponseEntity.ok(ApiResponse.success(result));
    }

    // ─── Filter by User ──────────────────────────────────────────────────────────

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get tasks assigned to a specific user")
    public ResponseEntity<ApiResponse<Page<TaskResponse>>> getTasksByUser(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        Sort sort = direction.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return ResponseEntity.ok(ApiResponse.success(taskService.getTasksByUser(userId, pageable)));
    }

    // ─── Overdue ─────────────────────────────────────────────────────────────────

    @GetMapping("/overdue")
    @Operation(summary = "Get all overdue tasks")
    public ResponseEntity<ApiResponse<List<TaskResponse>>> getOverdueTasks() {
        return ResponseEntity.ok(ApiResponse.success(taskService.getOverdueTasks()));
    }

    @GetMapping("/overdue/project/{projectId}")
    @Operation(summary = "Get overdue tasks by project")
    public ResponseEntity<ApiResponse<List<TaskResponse>>> getOverdueTasksByProject(@PathVariable Long projectId) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getOverdueTasksByProject(projectId)));
    }

    // ─── Comments ────────────────────────────────────────────────────────────────

    @PostMapping("/{taskId}/comments")
    @Operation(summary = "Add a comment to a task")
    public ResponseEntity<ApiResponse<TaskCommentResponse>> addComment(
            @PathVariable Long taskId,
            @Valid @RequestBody AddCommentRequest request) {
        log.info("POST /api/tasks/{}/comments", taskId);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(taskService.addComment(taskId, request), "Comment added successfully"));
    }

    @GetMapping("/{taskId}/comments")
    @Operation(summary = "Get comments for a task")
    public ResponseEntity<ApiResponse<Page<TaskCommentResponse>>> getComments(
            @PathVariable Long taskId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return ResponseEntity.ok(ApiResponse.success(taskService.getCommentsByTask(taskId, pageable)));
    }

    // ─── History ─────────────────────────────────────────────────────────────────

    @GetMapping("/{taskId}/history")
    @Operation(summary = "Get full audit history of a task")
    public ResponseEntity<ApiResponse<List<TaskActivityResponse>>> getTaskHistory(@PathVariable Long taskId) {
        log.info("GET /api/tasks/{}/history", taskId);
        return ResponseEntity.ok(ApiResponse.success(taskService.getTaskHistory(taskId)));
    }
}
