package com.taskmanager.service;

import com.taskmanager.dto.response.DashboardResponse;
import com.taskmanager.dto.response.ProjectResponse;

public interface DashboardService {

    DashboardResponse getGlobalDashboard();

    ProjectResponse getProjectDashboard(Long projectId);
}
