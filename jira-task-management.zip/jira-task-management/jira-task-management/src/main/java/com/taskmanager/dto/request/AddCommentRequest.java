package com.taskmanager.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AddCommentRequest {

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotBlank(message = "Comment text is required")
    private String commentText;
}
