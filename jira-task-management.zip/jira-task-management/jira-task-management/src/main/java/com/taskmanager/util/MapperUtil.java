package com.taskmanager.util;

import com.taskmanager.dto.response.TaskActivityResponse;
import com.taskmanager.dto.response.TaskCommentResponse;
import com.taskmanager.dto.response.TaskResponse;
import com.taskmanager.dto.response.UserResponse;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskActivity;
import com.taskmanager.entity.TaskComment;
import com.taskmanager.entity.User;

public class MapperUtil {

    private MapperUtil() {
        // Utility class - no instantiation
    }

    public static UserResponse toUserResponse(User user) {
        if (user == null) return null;
        return UserResponse.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .createdAt(user.getCreatedAt())
                .build();
    }

    public static TaskResponse toTaskResponse(Task task) {
        if (task == null) return null;
        return TaskResponse.builder()
                .id(task.getId())
                .title(task.getTitle())
                .description(task.getDescription())
                .status(task.getStatus())
                .priority(task.getPriority())
                .assignedUser(toUserResponse(task.getAssignedUser()))
                .projectId(task.getProject() != null ? task.getProject().getId() : null)
                .projectName(task.getProject() != null ? task.getProject().getName() : null)
                .dueDate(task.getDueDate())
                .overdue(task.isOverdue())
                .createdAt(task.getCreatedAt())
                .updatedAt(task.getUpdatedAt())
                .build();
    }

    public static TaskCommentResponse toCommentResponse(TaskComment comment) {
        if (comment == null) return null;
        return TaskCommentResponse.builder()
                .id(comment.getId())
                .taskId(comment.getTask() != null ? comment.getTask().getId() : null)
                .user(toUserResponse(comment.getUser()))
                .commentText(comment.getCommentText())
                .createdAt(comment.getCreatedAt())
                .build();
    }

    public static TaskActivityResponse toActivityResponse(TaskActivity activity) {
        if (activity == null) return null;
        return TaskActivityResponse.builder()
                .id(activity.getId())
                .taskId(activity.getTask() != null ? activity.getTask().getId() : null)
                .activityType(activity.getActivityType())
                .oldValue(activity.getOldValue())
                .newValue(activity.getNewValue())
                .updatedBy(toUserResponse(activity.getUpdatedBy()))
                .timestamp(activity.getTimestamp())
                .build();
    }
}
