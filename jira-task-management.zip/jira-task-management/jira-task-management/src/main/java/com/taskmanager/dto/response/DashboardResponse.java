package com.taskmanager.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DashboardResponse {

    private long totalProjects;
    private long totalTasks;
    private long completedTasks;
    private long pendingTasks;
    private long inProgressTasks;
    private long blockedTasks;
    private long overdueTasks;
    private double overallProgressPercentage;
}
