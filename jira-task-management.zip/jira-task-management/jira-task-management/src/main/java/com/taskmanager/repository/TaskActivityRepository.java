package com.taskmanager.repository;

import com.taskmanager.entity.TaskActivity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskActivityRepository extends JpaRepository<TaskActivity, Long> {

    List<TaskActivity> findByTaskIdOrderByTimestampDesc(Long taskId);

    Page<TaskActivity> findByTaskId(Long taskId, Pageable pageable);
}
