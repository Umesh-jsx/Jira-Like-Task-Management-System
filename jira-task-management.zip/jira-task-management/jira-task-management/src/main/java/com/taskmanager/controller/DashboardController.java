package com.taskmanager.controller;

import com.taskmanager.dto.response.ApiResponse;
import com.taskmanager.dto.response.DashboardResponse;
import com.taskmanager.dto.response.ProjectResponse;
import com.taskmanager.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Dashboard", description = "APIs for dashboard metrics")
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping
    @Operation(summary = "Get global dashboard metrics")
    public ResponseEntity<ApiResponse<DashboardResponse>> getGlobalDashboard() {
        log.info("GET /api/dashboard");
        return ResponseEntity.ok(ApiResponse.success(dashboardService.getGlobalDashboard()));
    }

    @GetMapping("/project/{projectId}")
    @Operation(summary = "Get project-level dashboard metrics")
    public ResponseEntity<ApiResponse<ProjectResponse>> getProjectDashboard(@PathVariable Long projectId) {
        log.info("GET /api/dashboard/project/{}", projectId);
        return ResponseEntity.ok(ApiResponse.success(dashboardService.getProjectDashboard(projectId)));
    }
}
