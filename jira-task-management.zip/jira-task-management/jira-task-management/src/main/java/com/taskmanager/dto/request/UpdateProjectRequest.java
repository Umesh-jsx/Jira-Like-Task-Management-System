package com.taskmanager.dto.request;

import lombok.Data;

@Data
public class UpdateProjectRequest {

    private String name;

    private String description;
}
