package com.taskmanager.service.impl;

import com.taskmanager.dto.request.AddCommentRequest;
import com.taskmanager.dto.request.CreateTaskRequest;
import com.taskmanager.dto.request.UpdateTaskRequest;
import com.taskmanager.dto.response.TaskActivityResponse;
import com.taskmanager.dto.response.TaskCommentResponse;
import com.taskmanager.dto.response.TaskResponse;
import com.taskmanager.entity.*;
import com.taskmanager.enums.ActivityType;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.exception.ResourceNotFoundException;
import com.taskmanager.repository.*;
import com.taskmanager.service.TaskService;
import com.taskmanager.util.MapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final ProjectRepository projectRepository;
    private final UserRepository userRepository;
    private final TaskCommentRepository commentRepository;
    private final TaskActivityRepository activityRepository;

    @Override
    @Transactional
    public TaskResponse createTask(CreateTaskRequest request) {
        log.info("Creating task: {}", request.getTitle());
        Project project = projectRepository.findById(request.getProjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Project", request.getProjectId()));

        User assignedUser = null;
        if (request.getAssignedUserId() != null) {
            assignedUser = userRepository.findById(request.getAssignedUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("User", request.getAssignedUserId()));
        }

        Task task = Task.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .status(request.getStatus() != null ? request.getStatus() : TaskStatus.OPEN)
                .priority(request.getPriority() != null ? request.getPriority() : TaskPriority.MEDIUM)
                .project(project)
                .assignedUser(assignedUser)
                .dueDate(request.getDueDate())
                .build();

        Task saved = taskRepository.save(task);

        // Log creation activity
        recordActivity(saved, ActivityType.TASK_CREATED, null, saved.getStatus().name(),
                assignedUser != null ? assignedUser : project.getCreatedBy());

        log.info("Task created with id: {}", saved.getId());
        return MapperUtil.toTaskResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public TaskResponse getTaskById(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task", id));
        return MapperUtil.toTaskResponse(task);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getAllTasks(Pageable pageable) {
        return taskRepository.findAll(pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getTasksByProject(Long projectId, Pageable pageable) {
        if (!projectRepository.existsById(projectId)) {
            throw new ResourceNotFoundException("Project", projectId);
        }
        return taskRepository.findByProjectId(projectId, pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getTasksByUser(Long userId, Pageable pageable) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User", userId);
        }
        return taskRepository.findByAssignedUserId(userId, pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getTasksByStatus(TaskStatus status, Pageable pageable) {
        return taskRepository.findByStatus(status, pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getTasksByProjectAndStatus(Long projectId, TaskStatus status, Pageable pageable) {
        return taskRepository.findByProjectIdAndStatus(projectId, status, pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getTasksByProjectAndPriority(Long projectId, TaskPriority priority, Pageable pageable) {
        return taskRepository.findByProjectIdAndPriority(projectId, priority, pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> searchTasks(String keyword, Pageable pageable) {
        return taskRepository.searchByKeyword(keyword, pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> searchTasksByProject(Long projectId, String keyword, Pageable pageable) {
        return taskRepository.searchByProjectAndKeyword(projectId, keyword, pageable).map(MapperUtil::toTaskResponse);
    }

    @Override
    @Transactional
    public TaskResponse updateTask(Long id, UpdateTaskRequest request) {
        log.info("Updating task with id: {}", id);
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task", id));

        User updatedBy = userRepository.findById(request.getUpdatedById())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUpdatedById()));

        // Track and apply changes
        if (request.getTitle() != null && !request.getTitle().equals(task.getTitle())) {
            recordActivity(task, ActivityType.TITLE_CHANGED, task.getTitle(), request.getTitle(), updatedBy);
            task.setTitle(request.getTitle());
        }
        if (request.getDescription() != null && !request.getDescription().equals(task.getDescription())) {
            recordActivity(task, ActivityType.DESCRIPTION_CHANGED,
                    task.getDescription(), request.getDescription(), updatedBy);
            task.setDescription(request.getDescription());
        }
        if (request.getStatus() != null && request.getStatus() != task.getStatus()) {
            recordActivity(task, ActivityType.STATUS_CHANGED,
                    task.getStatus().name(), request.getStatus().name(), updatedBy);
            task.setStatus(request.getStatus());
        }
        if (request.getPriority() != null && request.getPriority() != task.getPriority()) {
            recordActivity(task, ActivityType.PRIORITY_CHANGED,
                    task.getPriority().name(), request.getPriority().name(), updatedBy);
            task.setPriority(request.getPriority());
        }
        if (request.getDueDate() != null && !request.getDueDate().equals(task.getDueDate())) {
            recordActivity(task, ActivityType.DUE_DATE_CHANGED,
                    task.getDueDate() != null ? task.getDueDate().toString() : null,
                    request.getDueDate().toString(), updatedBy);
            task.setDueDate(request.getDueDate());
        }
        if (request.getAssignedUserId() != null) {
            User newAssignee = userRepository.findById(request.getAssignedUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("User", request.getAssignedUserId()));
            String oldAssignee = task.getAssignedUser() != null ? task.getAssignedUser().getName() : "Unassigned";
            if (!newAssignee.getId().equals(task.getAssignedUser() != null ? task.getAssignedUser().getId() : null)) {
                recordActivity(task, ActivityType.ASSIGNEE_CHANGED, oldAssignee, newAssignee.getName(), updatedBy);
                task.setAssignedUser(newAssignee);
            }
        }

        Task updated = taskRepository.save(task);
        log.info("Task updated: {}", updated.getId());
        return MapperUtil.toTaskResponse(updated);
    }

    @Override
    @Transactional
    public void deleteTask(Long id) {
        log.info("Deleting task with id: {}", id);
        if (!taskRepository.existsById(id)) {
            throw new ResourceNotFoundException("Task", id);
        }
        taskRepository.deleteById(id);
    }

    @Override
    @Transactional
    public TaskCommentResponse addComment(Long taskId, AddCommentRequest request) {
        log.info("Adding comment to task: {}", taskId);
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Task", taskId));
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));

        TaskComment comment = TaskComment.builder()
                .task(task)
                .user(user)
                .commentText(request.getCommentText())
                .build();

        TaskComment saved = commentRepository.save(comment);

        // Log comment activity
        recordActivity(task, ActivityType.COMMENT_ADDED, null, request.getCommentText(), user);

        return MapperUtil.toCommentResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskCommentResponse> getCommentsByTask(Long taskId, Pageable pageable) {
        if (!taskRepository.existsById(taskId)) {
            throw new ResourceNotFoundException("Task", taskId);
        }
        return commentRepository.findByTaskId(taskId, pageable).map(MapperUtil::toCommentResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TaskActivityResponse> getTaskHistory(Long taskId) {
        if (!taskRepository.existsById(taskId)) {
            throw new ResourceNotFoundException("Task", taskId);
        }
        return activityRepository.findByTaskIdOrderByTimestampDesc(taskId)
                .stream().map(MapperUtil::toActivityResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TaskResponse> getOverdueTasks() {
        return taskRepository.findOverdueTasks(LocalDate.now())
                .stream().map(MapperUtil::toTaskResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TaskResponse> getOverdueTasksByProject(Long projectId) {
        if (!projectRepository.existsById(projectId)) {
            throw new ResourceNotFoundException("Project", projectId);
        }
        return taskRepository.findOverdueTasksByProject(projectId, LocalDate.now())
                .stream().map(MapperUtil::toTaskResponse).collect(Collectors.toList());
    }

    private void recordActivity(Task task, ActivityType activityType,
                                 String oldValue, String newValue, User updatedBy) {
        TaskActivity activity = TaskActivity.builder()
                .task(task)
                .activityType(activityType)
                .oldValue(oldValue)
                .newValue(newValue)
                .updatedBy(updatedBy)
                .build();
        activityRepository.save(activity);
    }
}
