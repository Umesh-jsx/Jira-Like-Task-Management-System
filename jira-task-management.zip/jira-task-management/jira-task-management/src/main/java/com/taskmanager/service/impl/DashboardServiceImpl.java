package com.taskmanager.service.impl;

import com.taskmanager.dto.response.DashboardResponse;
import com.taskmanager.dto.response.ProjectResponse;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.exception.ResourceNotFoundException;
import com.taskmanager.repository.ProjectRepository;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.DashboardService;
import com.taskmanager.service.ProjectService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Slf4j
public class DashboardServiceImpl implements DashboardService {

    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;
    private final ProjectService projectService;

    @Override
    @Transactional(readOnly = true)
    public DashboardResponse getGlobalDashboard() {
        log.info("Computing global dashboard metrics");
        long totalProjects = projectRepository.count();
        long totalTasks = taskRepository.count();
        long completedTasks = taskRepository.findByStatus(TaskStatus.DONE,
                org.springframework.data.domain.Pageable.unpaged()).getTotalElements();
        long inProgressTasks = taskRepository.findByStatus(TaskStatus.IN_PROGRESS,
                org.springframework.data.domain.Pageable.unpaged()).getTotalElements();
        long blockedTasks = taskRepository.findByStatus(TaskStatus.BLOCKED,
                org.springframework.data.domain.Pageable.unpaged()).getTotalElements();
        long pendingTasks = totalTasks - completedTasks;
        long overdueTasks = taskRepository.findOverdueTasks(LocalDate.now()).size();
        double progress = totalTasks > 0 ? Math.round((completedTasks * 100.0 / totalTasks) * 100.0) / 100.0 : 0.0;

        return DashboardResponse.builder()
                .totalProjects(totalProjects)
                .totalTasks(totalTasks)
                .completedTasks(completedTasks)
                .pendingTasks(pendingTasks)
                .inProgressTasks(inProgressTasks)
                .blockedTasks(blockedTasks)
                .overdueTasks(overdueTasks)
                .overallProgressPercentage(progress)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public ProjectResponse getProjectDashboard(Long projectId) {
        log.info("Computing dashboard for project: {}", projectId);
        if (!projectRepository.existsById(projectId)) {
            throw new ResourceNotFoundException("Project", projectId);
        }
        return projectService.getProjectById(projectId);
    }
}
