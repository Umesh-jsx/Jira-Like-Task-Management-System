package com.taskmanager.service;

import com.taskmanager.dto.request.AddCommentRequest;
import com.taskmanager.dto.request.CreateTaskRequest;
import com.taskmanager.dto.request.UpdateTaskRequest;
import com.taskmanager.dto.response.TaskActivityResponse;
import com.taskmanager.dto.response.TaskCommentResponse;
import com.taskmanager.dto.response.TaskResponse;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TaskService {

    TaskResponse createTask(CreateTaskRequest request);

    TaskResponse getTaskById(Long id);

    Page<TaskResponse> getAllTasks(Pageable pageable);

    Page<TaskResponse> getTasksByProject(Long projectId, Pageable pageable);

    Page<TaskResponse> getTasksByUser(Long userId, Pageable pageable);

    Page<TaskResponse> getTasksByStatus(TaskStatus status, Pageable pageable);

    Page<TaskResponse> getTasksByProjectAndStatus(Long projectId, TaskStatus status, Pageable pageable);

    Page<TaskResponse> getTasksByProjectAndPriority(Long projectId, TaskPriority priority, Pageable pageable);

    Page<TaskResponse> searchTasks(String keyword, Pageable pageable);

    Page<TaskResponse> searchTasksByProject(Long projectId, String keyword, Pageable pageable);

    TaskResponse updateTask(Long id, UpdateTaskRequest request);

    void deleteTask(Long id);

    TaskCommentResponse addComment(Long taskId, AddCommentRequest request);

    Page<TaskCommentResponse> getCommentsByTask(Long taskId, Pageable pageable);

    List<TaskActivityResponse> getTaskHistory(Long taskId);

    List<TaskResponse> getOverdueTasks();

    List<TaskResponse> getOverdueTasksByProject(Long projectId);
}
