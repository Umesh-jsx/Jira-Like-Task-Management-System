package com.taskmanager.config;

import com.taskmanager.entity.Project;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskComment;
import com.taskmanager.entity.User;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.enums.UserRole;
import com.taskmanager.repository.ProjectRepository;
import com.taskmanager.repository.TaskCommentRepository;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.time.LocalDate;
import java.util.List;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataInitializer {

    @Bean
    @Profile("h2")
    public CommandLineRunner loadSampleData(
            UserRepository userRepository,
            ProjectRepository projectRepository,
            TaskRepository taskRepository,
            TaskCommentRepository commentRepository) {

        return args -> {
            log.info("Loading sample data...");

            // ── Users ──────────────────────────────────────────────────────────
            User alice = userRepository.save(User.builder()
                    .name("Alice Johnson").email("alice@example.com").role(UserRole.ADMIN).build());
            User bob = userRepository.save(User.builder()
                    .name("Bob Smith").email("bob@example.com").role(UserRole.DEVELOPER).build());
            User carol = userRepository.save(User.builder()
                    .name("Carol White").email("carol@example.com").role(UserRole.TESTER).build());
            User dave = userRepository.save(User.builder()
                    .name("Dave Brown").email("dave@example.com").role(UserRole.MANAGER).build());

            // ── Projects ───────────────────────────────────────────────────────
            Project ecomProject = projectRepository.save(Project.builder()
                    .name("E-Commerce Platform")
                    .description("Build a full-featured e-commerce web application")
                    .createdBy(alice).build());

            Project crmProject = projectRepository.save(Project.builder()
                    .name("CRM System")
                    .description("Customer Relationship Management system for sales team")
                    .createdBy(dave).build());

            // ── Tasks for E-Commerce ───────────────────────────────────────────
            Task t1 = taskRepository.save(Task.builder()
                    .title("Design database schema")
                    .description("Design ER diagram and create all necessary database tables")
                    .status(TaskStatus.DONE)
                    .priority(TaskPriority.HIGH)
                    .project(ecomProject)
                    .assignedUser(bob)
                    .dueDate(LocalDate.now().minusDays(5))
                    .build());

            Task t2 = taskRepository.save(Task.builder()
                    .title("Implement user authentication")
                    .description("JWT-based login and registration flow")
                    .status(TaskStatus.IN_PROGRESS)
                    .priority(TaskPriority.CRITICAL)
                    .project(ecomProject)
                    .assignedUser(bob)
                    .dueDate(LocalDate.now().plusDays(3))
                    .build());

            Task t3 = taskRepository.save(Task.builder()
                    .title("Product listing API")
                    .description("REST endpoints for browsing and filtering products")
                    .status(TaskStatus.OPEN)
                    .priority(TaskPriority.MEDIUM)
                    .project(ecomProject)
                    .assignedUser(bob)
                    .dueDate(LocalDate.now().plusDays(7))
                    .build());

            Task t4 = taskRepository.save(Task.builder()
                    .title("Write integration tests")
                    .description("Cover all REST endpoints with integration tests")
                    .status(TaskStatus.OPEN)
                    .priority(TaskPriority.MEDIUM)
                    .project(ecomProject)
                    .assignedUser(carol)
                    .dueDate(LocalDate.now().plusDays(10))
                    .build());

            Task t5 = taskRepository.save(Task.builder()
                    .title("Payment gateway integration")
                    .description("Integrate Stripe for payment processing — blocked on API keys")
                    .status(TaskStatus.BLOCKED)
                    .priority(TaskPriority.HIGH)
                    .project(ecomProject)
                    .assignedUser(bob)
                    .dueDate(LocalDate.now().minusDays(2))   // intentionally overdue
                    .build());

            // ── Tasks for CRM ──────────────────────────────────────────────────
            Task t6 = taskRepository.save(Task.builder()
                    .title("Lead management module")
                    .description("CRUD for leads with pipeline stages")
                    .status(TaskStatus.IN_PROGRESS)
                    .priority(TaskPriority.HIGH)
                    .project(crmProject)
                    .assignedUser(bob)
                    .dueDate(LocalDate.now().plusDays(5))
                    .build());

            Task t7 = taskRepository.save(Task.builder()
                    .title("Email notification service")
                    .description("Automated emails for lead status changes")
                    .status(TaskStatus.OPEN)
                    .priority(TaskPriority.LOW)
                    .project(crmProject)
                    .assignedUser(carol)
                    .dueDate(LocalDate.now().plusDays(14))
                    .build());

            // ── Comments ───────────────────────────────────────────────────────
            commentRepository.saveAll(List.of(
                    TaskComment.builder().task(t1).user(alice)
                            .commentText("Schema reviewed and approved. Great work Bob!").build(),
                    TaskComment.builder().task(t2).user(dave)
                            .commentText("Please add refresh token support as well.").build(),
                    TaskComment.builder().task(t5).user(bob)
                            .commentText("Waiting for Stripe test API keys from the finance team.").build(),
                    TaskComment.builder().task(t6).user(dave)
                            .commentText("Remember to add bulk import functionality for leads.").build()
            ));

            log.info("Sample data loaded: {} users, {} projects, {} tasks",
                    userRepository.count(), projectRepository.count(), taskRepository.count());
        };
    }
}
